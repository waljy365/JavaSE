package com.itheima.d5_map;
/*
     目标：掌握Map集合的常用方法(重点)
        public V put(K key,V value)	添加元素
        public int size()	获取集合的大小
        public void clear()	清空集合
        public boolean isEmpty()	判断集合是否为空，为空返回true , 反之
        public V get(Object key)	根据键获取对应值
        public V remove(Object key)	根据键删除整个元素
        public  boolean containsKey(Object key)	判断是否包含某个键
        public boolean containsValue(Object value)	判断是否包含某个值
        public Set<K> keySet()	获取全部键的集合
        public Collection<V> values()	获取Map集合的全部值
 */
public class MapTest2 {}
