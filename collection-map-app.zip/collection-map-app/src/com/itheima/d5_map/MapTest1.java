package com.itheima.d5_map;

/*
    目标：掌握Map集合的特点。

    Map集合体系的特点
        注意：Map系列集合的特点都是由键决定的，值只是一个附属品，值是不做要求的

    HashMap（由键决定特点）: 无序、不重复、无索引；  （用的最多）
    LinkedHashMap （由键决定特点）:由键决定的特点：有序、不重复、无索引。
    TreeMap （由键决定特点）:按照大小默认升序排序、不重复、无索引。
 */
public class MapTest1 {
    public static void main(String[] args) {}
}
