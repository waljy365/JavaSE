package com.itheima.d1_collection_set;

/*
    目标：掌握TreeSet集合的使用。

    排序规则 :
        根据compareTo方法的返回值进行指定元素位置
        如果返回值为负数，表示当前存入的元素是较小值，存左边
        如果返回值为0，表示当前存入的元素相等 , 不存
        如果返回值为正数，表示当前存入的元素是较大值，存右边
    this表示当前要存储的元素 , o表示的是已经存在的元素
 */
public class SetTest4 {
    public static void main(String[] args) {

    }
}
