package com.itheima.d1_collection_set;
/*
    目标：整体了解一下Set系列集合的特点

    Set集合的体系特点
        HashSet : 无序、不重复、无索引。
        LinkedHashSet：有序、不重复、无索引。
        TreeSet：排序、不重复、无索引。

    需求 : 演示Set集合的每一个实现类的特点
 */
public class SetTest1 {
    public static void main(String[] args) {
    }
}
