package com.itheima.d1_collection_set;
/*
    LinkedHashSet：有序、不重复、无索引。
 */
public class LinkedHashSetTest {
    public static void main(String[] args) {

    }
}
