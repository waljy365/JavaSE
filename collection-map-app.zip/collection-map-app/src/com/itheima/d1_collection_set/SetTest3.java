package com.itheima.d1_collection_set;

/*
     目标：自定义的类型的对象，比如两个内容一样的学生对象，如果让HashSet集合能够去重复！
 */
public class SetTest3 {
}
