package com.itheima.d4_collections;

/*
     目标：掌握Collections集合工具类的使用。
        public static <T> boolean addAll(Collection<? super T> c, T... elements)	给集合批量添加元素
        public static void shuffle(List<?> list) 	打乱List集合中的元素顺序
        public static <T> void sort(List<T> list)	对List集合中的元素进行升序排序
        public static <T> void sort(List<T> list，Comparator<? super T> c)	对List集合中元素，按照比较器对象指定的规则进行排序
 */
public class CollectionsTest1 {
    public static void main(String[] args) {}
}
