package com.itheima.d3_stream;
import java.util.*;
import java.util.stream.Collectors;

/*
   目标 : 初步体验Stream流的方便与快捷

   需求 : 把集合中所有以“张”开头，且是3个字的元素存储到一个新的集合。
 */
public class StreamTest1 {
    public static void main(String[] args) {
        List<String> names = new ArrayList<>();
        Collections.addAll(names, "张三丰","张无忌","周芷若","赵敏","张强");
    }
}
