package com.itheima.d2_collection_nesting;

/*
      目标：理解集合的嵌套。
      江苏省 = "南京市","扬州市","苏州市“,"无锡市","常州市"
      湖北省 = "武汉市","孝感市","十堰市","宜昌市","鄂州市"
      河北省 = "石家庄市","唐山市", "邢台市", "保定市", "张家口市"
 */
public class Test {
    public static void main(String[] args) {
    }
}
