package com.itheima.d5_recursion;

/**
 * 目标：认识一下递归的形式。
 */
public class RecursionTest1 {
    public static void main(String[] args) {
    }

    // 直接方法递归

    // 间接方法递归
}
