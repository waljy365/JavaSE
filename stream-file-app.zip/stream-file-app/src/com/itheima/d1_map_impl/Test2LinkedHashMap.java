package com.itheima.d1_map_impl;

import java.util.LinkedHashMap;

/*
    目标：掌握LinkedHashMap的底层原理。
 */
public class Test2LinkedHashMap {
    public static void main(String[] args) {


    }
}
