package com.itheima.d4_file;

/*
  目标：掌握File创建和删除文件相关的方法。

    public boolean createNewFile()	创建一个新的空的文件
    public boolean mkdir()	只能创建一级文件夹
    public boolean mkdirs()	可以创建多级文件夹

    public boolean delete()	删除文件、空文件夹
 */
public class FileTest3 {
    public static void main(String[] args) {
    }
}
